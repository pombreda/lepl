
'''
If we want to support ambiguous lexers then we need a ([token], stream) stream.
'''